%=======================
% Syntax: convert_pix_lut.m
% Description: Illustrated below is the necessary functions for writing a Matlab function which applies a 
%   Look up Table (LUT), given the variables presented in the written
%   report titled, 'GGS680_Fa18_3_brendan_casey.pdf'
% Input: Values the input image stjohn.tif (f), the number of bits per
%   pixel (n), the input LUT values (in) 
% Output: The output LUT values (out), Figure 1 ('Original stjohn.tif'),
%   Figure 2 ('Adjusted stjohn.tif (with LUT)')
%=======================
%Brendan Casey
%Assignment 3
%November 1, 2018
%Question 1
%=======================  



function g = convert_pix_lut(f, LUT)
  %Task 1:
    % Part a:
        % Write a Matlab function which applies a Lookup Table (LUT) pixel
        % value transformation ot a given image.  The function will receive
        % as the input the following parameters:
        
        % where:
         % f = input image
         % n = number of bits per pixel
         % in = input LUT values
         % out = output LUT values
   [row,col] = size(f); % This returns the number of rows and columns in the image(f).  I.E. In order for the function to apply the transformation to each pixel in the image, we need to define the size of the image by writing this
         g = f;  % This creates a copy of the original image
            in = LUT(:,1);
            out = LUT(:,2);

for i = 1:row % First loop
   
    for j = 1:col % Second loop
        
       % Convert the pixel value at image corrdinates(i,j) to the new value
       % according to the LUT that was provided (note the here the LUT is
       % comprised of two input variables fo the fucntion, namely "in" and
       % "out").
        g(i, j) = out(in(f(i,j)+1));

    end 
   
end

%Command line code (entered one line at a time):
 
% f = imread('stjohn.tif')
% LUT = importdata('stjohn_LUT.mat')
% in = LUT(:,1);
% out = LUT(:,2);
% n= 8
% convert_pix_lut(f, LUT)

%Apply function to the image stjohn.tif using the LUT in
%stjohn_LUT.mat and show the resulting image: 

I = imread('stjohn.tif'); 
 figure, imshow(I), title('Original stjohn.tif');
 figure, imshow(g), title('Adjusted stjohn.tif (with LUT)');

%The general effect that the function has on the image is a contrast enhancement.
% Pixels that were once similar in value, are now more separated to
% illustrate geometric patterns that are otherwise harder to see in the original image. 


