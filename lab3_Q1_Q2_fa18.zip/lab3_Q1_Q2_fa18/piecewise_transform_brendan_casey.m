
%=======================
% Syntax: piecewise_transform.m
% Description: Illustrated below is the necessary functions for calculating
% a piecewise transformation (given the equations presented in the written
% report titled, 'GGS680_Fa18_3_brendan_casey.pdf'
% Input: transformation values (r1, r2, r3, s1, s2, s3), the input image
%   Landsat_DC_pan.jpg (f), the number of bits per pixel (n)
% Output: A vector, and B vector, each composed of values (a1, a2, a3, a4,
%   b1, b2, b3, and b4) representing calculations performed as represented by
%   the equations in the report titled 'GGS680_Fa18_3_brendan_casey.pdf',
%   and the output image (transformed image (T))
%=======================
%Brendan Casey
%Assignment 3
%November 1, 2018
%Question 2
%=======================    

function T = piecewise_transform(f,n,r1,s1,r2,s2,r3,s3)

%Structure of this function:
    
    % 1)Find paremeters of each line segment(a[i.e. "slope"], and b [i.e.
    %  y-intercept] of each line), based on the coord. of the breakpoints and
    %  the end points.

        L = 2^n;
        a1= s1/r1;
        a2= (s2-s1)/(r2-r1);
        a3= (s3-s2)/(r3-r2);
        a4= ((L-1)-s3)/((L-1)-r3); 

        b1= 0 ;
        b2= ((s1*r2)-(s2*r1))/(r2-r1);
        b3= ((s2*r3)-(s3*r2))/(r3-r2);
        b4= ((s3*(L-1)-(L-1)*r3))/((L-1)-r3);

    % 2) Put all paremeters into two vectors: A, and B
        % Where:
            
            A=[a1,a2,a3,a4];
            B=[b1,b2,b3,b4];

    % 3) Define size of image for the function to run through all pixels
       
        [row,col] = size (f);

        T=f; %This initializes transformation "T" as it relates to Image "f".  I.E. Input image = output image
 
    % 4) Define a double loop, so that the function can run throgh all rows and all columns:
            % I.E. This runs through every pixel row(i) and col(j):
            for i = 1: row
                for j = 1:col
    % 5) Find which line to use;
            % I.E. Given a pixel value, what is the line segment you need
            % to use?
                 if f(i,j)<=r1
                     flag = 1;
                 end
                 
                 if f(i,j)>r1 && f(i,j)<=r2
                     flag = 2;
                 end
                 
                 if f(i,j)>r2 && f(i,j)<=r3
                     flag = 3;
                 end
                 
                 if f(i,j)>r3 && f(i,j)<=(L-1)
                     flag = 4;
                 end
                 
                 T(i,j)=A(flag)*f(i,j) +B(flag);  % All pixel values to "T" are updated here. I.E. [New pixel value] = [slope of transformation line segment to which pixel corresponds to] * [current pixel value] + [Intercept of line segment to which pixel value corresponds to
    
                end  %close loop for col
                
            end  %close loop for row

T =uint8(T); %Output image of T = Uint8 variable

%Apply function to the image Landsat_DC_pan.jpg(I) using the Transformation
%and show the resulting image(T):

I = imread ('Landsat_DC_pan.jpg'); 
figure, imshow(I), title('Original Landsat DC pan.jpg');
figure, imshow(T), title('Piecewise Linear Transformation of Landsat DC pan.jpg');

end





%Command line code (entered one line at a time):

% 1)
    % f = imread('Landsat_DC_pan.jpg')
    
    % n = 8
    
    % r1 =45
    % r2 = 125
    % r3 = 180
    % s1 = 21
    % s2 = 140
    % s3 = 210

        % (or) 
            % r1 =45;r2 = 125; r3 = 180; s1 = 21; s2 = 140; s3 = 210
     
    %[Hit Enter] 

    
% 2) 
    % piecewise_transform(f,n,r1,s1,r2,s2,r3,s3)
    % (This will run the entire Pieceweise Transformation Function)
    
    %[Hit Enter]
    
    
% 3) 
    % L = 2^n;
    % a1= s1/r1;
    % a2= (s2-s1)/(r2-r1);
    % a3= (s3-s2)/(r3-r2);
    % a4= ((L-1)-s3)/((L-1)-r3)
    
        % (or)
            % L = 2^n;a1= s1/r1;a2= (s2-s1)/(r2-r1);a3= (s3-s2)/(r3-r2);a4= ((L-1)-s3)/((L-1)-r3)
    
    %[Hit Enter]
    
    
% 4)
    % Alpha = a1;
    % Beta = a2;
    % Gamma = a3;
    % Delta = a4
    
        % (or)
            % Alpha = a1;Beta = a2;Gamma = a3;Delta = a4